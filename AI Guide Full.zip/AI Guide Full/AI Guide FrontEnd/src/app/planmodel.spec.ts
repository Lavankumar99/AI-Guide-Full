import { Planmodel } from './planmodel';

describe('Planmodel', () => {
  it('should create an instance', () => {
    expect(new Planmodel()).toBeTruthy();
  });
});
