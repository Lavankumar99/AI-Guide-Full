import { Feedbackmodel } from './feedbackmodel';

describe('Feedbackmodel', () => {
  it('should create an instance', () => {
    expect(new Feedbackmodel()).toBeTruthy();
  });
});
