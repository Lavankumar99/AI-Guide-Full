import { Placemodel } from './placemodel';

describe('Placemodel', () => {
  it('should create an instance', () => {
    expect(new Placemodel()).toBeTruthy();
  });
});
