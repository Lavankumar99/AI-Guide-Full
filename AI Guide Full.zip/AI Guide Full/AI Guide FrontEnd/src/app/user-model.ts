export class UserModel {
    id:number=0;
    fullName:string='';
    email:string='';
    password:string='';
    address:string='';
    mobileNumber:string='';

   
    constructor(){}

}
