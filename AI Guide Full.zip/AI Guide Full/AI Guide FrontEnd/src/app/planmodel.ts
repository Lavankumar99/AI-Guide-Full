export class Planmodel {

   
    startDate:string='';
    endDate:string='';
    placeIds:number[]=[];


    
}
